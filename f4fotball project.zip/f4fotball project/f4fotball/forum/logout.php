<?php
session_start();

if(!isset($_SESSION['username'])){
		echo "Kane sundesi prwta!!!";
}else{
session_unset();
session_destroy();
}

echo '<meta http-equiv="refresh" content="1; url=sindesi.php">';
die();


?>