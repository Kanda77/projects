<?php
session_start();
require_once('db_functions.php');
$conn=db_connect();
?>
 <!DOCTYPE html>
<html>
    <head>
       <meta charset="utf-8">
        <title>Approval Page</title>
        <link rel="stylesheet" type="text/css" href="startcss.css">
         <script type="text/javascript" src="admin.js"></script>
         <style>img[alt="www.000webhost.com"]{display:none;}</style>
    </head>
    <style>
#form{
  border-radius: 50px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin-top: 10%;
  position:absolute;
  top: 50%;
  left:50%;
  font-family: "Comic Sans MS", cursive, sans-serif;
  padding: 20px;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  display:block;
  }
  </style>
  <body>
      <center>
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but5()">Users Requests</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
      <div id="form">
    <?php
      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
       if($row['type']==='admin'){
        if(isset($_SESSION['username'])){
			echo "Hello Mr.".$_SESSION['username']."<br>";   
    	          if($_GET["id"]){
                  $check=mysqli_query($conn,"SELECT * FROM users WHERE id='".$_GET['id']."'");
                  if(!$check || $result= mysqli_num_rows($check)){
                      while($row = mysqli_fetch_assoc($check)){
                          echo "<h1>User:".$row['username']."</h1>";
                          echo "<h5>ID:".$row['id']."<h5/>";
                          ?>
                          <form action="" method="POST">
                          <input type="submit" name="submit" value="Accept">
                          </form>
                          <?php
                          if(isset ($_POST['submit'])){
                            $sql =  mysqli_query($conn,"UPDATE users SET Confirmation = 1 WHERE id = '".$_GET['id']."'");
                              echo "User has been accepted!";
                              echo '<meta http-equiv="refresh" content="2; url=accept.php">';
                           }
                           ?>
                           <form action="" method="POST">
                          <input type="submit" name="submit1" value="Decline">
                          </form>
                          <?php
                          if(isset ($_POST['submit1'])){
                            $sql =  mysqli_query($conn,"DELETE FROM users WHERE id = '".$_GET['id']."'");
                              echo "User has been Declined!";
                              echo '<meta http-equiv="refresh" content="2; url=accept.php">';
                           }
                           
                        }
                  }
              }else{
                  echo "No user request found!";
              }
        }
       }elseif($row['type']==='user'){
            echo "Nice Try!!</br>Only admins can enter here!";
            echo '<meta http-equiv="refresh" content="3; url=adminpage.php">';
        }else{
            echo "Nice Try!!</br>Log in first!!";
            echo '<meta http-equiv="refresh" content="3; url=sindesi.php">';
        }

?> 
</body>
</html>
