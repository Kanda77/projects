<?php
      session_start();
      require_once('db_functions.php');
      $conn=db_connect();
      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
      if($row['Confirmation']==0){
          echo "Wait for Admin confirmation!";
      }else{
           echo "Welcome to our Forum!";
           echo '<meta http-equiv="refresh" content="2; url=adminpage.php">';
      
      }
        ?>
        <!DOCTYPE html>
<html>
    <head>
       <meta charset="utf-8">
        <title>WAITING PAGE</title>
    </head>
    
</html>