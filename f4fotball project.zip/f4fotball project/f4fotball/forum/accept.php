<?php
session_start();
require_once('db_functions.php');
$conn=db_connect();

?>
<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="utf-8">
        <title>User Requests</title>
         <link rel="stylesheet" type="text/css" href="startcss.css">
         <script type="text/javascript" src="admin.js"></script>
         <style>img[alt="www.000webhost.com"]{display:none;}</style>



<input type="hidden" id="refreshed" value="no">

    </head>
    
    <body>
    
<?php 


      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
       if($row['type']==='admin'){
        if(isset($_SESSION['username'])){
			echo "Hello Mr.".$_SESSION['username']."<br>";
	?>
	<center>
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but5()">Users Requests</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
	<?php echo '<table border="3px white;" align="center" cellpadding="10" style="background-color:white;  margin-top:20%; border-collapse: collapse;">'?>
   
    <tr>
        <td>
            <span>ID</span>
        </td>
        <td width="300px;" style="text-align: center;">
            User
        </td>
    </tr>
    
	<?php
	$check = mysqli_query($conn,"SELECT * FROM users WHERE Confirmation='0'");

if(mysqli_num_rows($check) !=0){
   while($row=mysqli_fetch_assoc($check)){
       $id= $row['id'];
       echo "<tr>";
       echo "<td>".$row['id']."</td>";
        echo "<td style='text-align:center;'><a href=apodoxh.php?id=$id>".$row['username']."</a></td>";
        echo "</tr>";
   }
}
		}}elseif($row['type']==='user'){
            echo "Nice Try!!</br>Only admins can enter here!";
            echo '<meta http-equiv="refresh" content="3; url=adminpage.php">';
        }else{
            echo "Nice Try!!</br>Log in first!!";
            echo '<meta http-equiv="refresh" content="3; url=sindesi.php">';
        }
		?>
		</body>
		</html>