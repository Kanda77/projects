function but4(){
window.location.assign("adminpage.php");
 }
function but5(){
window.location.assign("accept.php");
 }
 function but6(){
window.location.assign("posts.php");
}
function but7(){
window.location.assign("questions.php");
}
function but8(){
window.location.assign("logout.php");
}