<?php
session_start();
require_once('db_functions.php');
$conn=db_connect();

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Posts</title>
         <link rel="stylesheet" type="text/css" href="startcss.css">
         <script type="text/javascript" src="admin.js"></script>
         <style>img[alt="www.000webhost.com"]{display:none;}</style>
        </head>
        <body>
          <style>
    #plaisio{
  border-radius: 50px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin-top: 10%;
  
  position:absolute;
  top: 70%;
  left:50%;
  font-family: "Comic Sans MS", cursive, sans-serif;
  padding: 20px;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  display:block;
  width:600px;
  height: 550px;
  }
          </style>
<?php
      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
       if($row['type']==='admin'){
        if(isset($_SESSION['username'])){
			echo "Hello Mr.".$_SESSION['username']."<br>";
?>
<center>
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but5()">Users Requests</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
	<div id="plaisio">
  <form action="" method="POST">
            <center>
        Post title: </br><input type="text" name="title"  value="<?php if (isset($_POST['title'])){echo $_POST['title'];} ?>" style="width:400px";></br></br>
       Content: </br><textarea  name="comment"  <?php if (isset($_POST['comment'])){echo $_POST['comment'];} ?> style="resize: none; width:400px; height:280px; " placeholder="Enter your text here..."></textarea><br>
      <input type="submit" name="submit" value="Submit">
  </form>
  </center>
<?php			
		}}
		else if($row['type']==='user'){
		    if(isset($_SESSION['username'])){
			echo "Hello ".$_SESSION['username']."<br>";
		    ?>
		    <center>
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
	        <div id="plaisio">
		    <form action="" method="POST">
            <center>
        Post title: </br><input type="text" name="title"  value="<?php if (isset($_POST['title'])){echo $_POST['title'];} ?>" style="width:400px";></br></br>
       Content: </br><textarea  name="comment"  <?php if (isset($_POST['comment'])){echo $_POST['comment'];} ?> style="resize: none; width:400px; height:280px; " placeholder="Enter your text here..."></textarea><br>
      <input type="submit" name="submit" value="Submit">
  </form>
  </center>
		    <?php
		    }}
		else {
		    echo "<script>alert('Log in first!!!');</script>";
		    echo '<meta http-equiv="refresh" content="2; url=sindesi.php">';
		}
		
      //$row=mysqli_fetch_array($result);
     
      ?>
  <?php
      if (isset($_POST['submit'])){
      
      $title= $_POST['title'];
      $question= $_POST['comment'];
      if($title && $question){
      $query="insert into posts values(DEFAULT,'$user', '$title' , '$question', DEFAULT ,DEFAULT)";
      $result=mysqli_query($conn,$query); 
      if($result===false){
					echo "Error is ". mysqli_error($conn);
					die();
				}else{
				    echo "Your post has been submitted!!!<br>";
        echo '<meta http-equiv="refresh" content="3; url=posts.php">';
        die();
      }
      }
      else{?>
          <center>
          <H3>Please fill in all the fields.</H3></center>
          <?php
          
      }}
?>
</div>
</div>
        </body>
        </html>