<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <form action="" method="POST">
      <textarea rows="4" cols="50" name="comment" placeholder="Enter your text here..."></textarea><br>
      <input type="submit" name="submit" value="Υποβολή Ερώτησης">
  </form>
  
  
</body>
</html>
