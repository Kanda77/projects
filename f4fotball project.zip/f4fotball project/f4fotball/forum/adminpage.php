<?php
session_start();
require_once('db_functions.php');
$conn=db_connect();

?>
<!DOCTYPE html>
<html>
    <head>
        
        <meta charset="utf-8">
        <title>Forum</title>
         <link rel="stylesheet" type="text/css" href="startcss.css">
         <script type="text/javascript" src="admin.js"></script>
         <style>img[alt="www.000webhost.com"]{display:none;}</style>



<input type="hidden" id="refreshed" value="no">

    </head>
    
    <body>
    
<?php 


      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
       if($row['type']==='admin'){
        if(isset($_SESSION['username'])){
			echo "Hello Mr.".$_SESSION['username']."<br>";
	?>
	<center>
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but5()">Users Requests</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
	<?php echo '<table border="3px white;" align="center" cellpadding="10" style="background-color:white; margin:250px 0 0 90px; border-collapse: collapse;">'?>
   
    <tr>
        <td>
            <span>ID</span>
        </td>
        <td width="400px;" style="text-align: center;">
            Post
        </td>
        <td width="80px;" style="text-align: center;">
        Likes
            </td>
        <td width="300px;" style="text-align: center;">
            User
        </td>
        <td width="100px;" style="text-align: center;">
            Date
        </td>
    </tr>
	<?php
	$check = mysqli_query($conn,"SELECT * FROM posts");

if(mysqli_num_rows($check) !=0){
   while($row=mysqli_fetch_assoc($check)){
       $id= $row['id'];
       echo "<tr>";
       echo "<td>".$row['id']."</td>";
        echo "<td style='text-align:center;'><a href=questions.php?id=$id>".$row['title']."</a></td>";
        echo "<td style='text-align:center;'>".$row['likes']."</td>";
        echo "<td style='text-align:center;'>".$row['name']."</td>";
        echo "<td style='text-align:center;'>".$row['date']."</td>";
        echo "</tr>";
   }
}
		}}
		else if($row['type']==='user'){
		    if(isset($_SESSION['username'])){
			echo "Hello ".$_SESSION['username']."<br>";
			?><center>
	
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
	</center>
	<?php echo '<table border="3px white;" align="center" cellpadding="10" style="background-color:white; margin:250px 0 0 90px; border-collapse: collapse;">'?>
   
    <tr>
        <td>
            <span>ID</span>
        </td>
        <td width="400px;" style="text-align: center;">
            Post
        </td>
        <td width="80px;" style="text-align: center;">
        Likes
            </td>
        <td width="300px;" style="text-align: center;">
            User
        </td>
        <td width="100px;" style="text-align: center;">
            Date
        </td>
    </tr>
			<?php
		$check = mysqli_query($conn,"SELECT * FROM posts");

if(mysqli_num_rows($check) !=0){
   while($row=mysqli_fetch_assoc($check)){
       $id= $row['id'];
       echo "<tr>";
       echo "<td>".$row['id']."</td>";
        echo "<td style='text-align:center;'><a href=questions.php?id=$id>".$row['title']."</a></td>";
        echo "<td style='text-align:center;'>".$row['likes']."</td>";
        echo "<td style='text-align:center;'>".$row['name']."</td>";
        echo "<td style='text-align:center;'>".$row['date']."</td>";
        echo "</tr>";
   }
}
		    
		   } }
		else {
		    echo "<script>alert('Log in first!!!');</script>";
		    echo '<meta http-equiv="refresh" content="0; url=sindesi.php">';
		}
		

/*$check= mysqli_query("SELECT * FROM posts");*/

      
		
?>

        </body>

</html>
