<?php
session_start();
require_once('db_functions.php');
$conn=db_connect();

?>
<!DOCTYPE html>
<html>
    
    <head>
        
        <meta charset="utf-8">
        <title>Posts</title>
        <link rel="stylesheet" type="text/css" href="todo.css">
         <link rel="stylesheet" type="text/css" href="startcss.css">
         <script type="text/javascript" src="admin.js"></script>
         <style>img[alt="www.000webhost.com"]{display:none;}</style>

<input type="hidden" id="refreshed" value="no">

    </head>
    <style>
    
#foot { 
  position: absolute;
  top: -200px;
  right: 0;
  -webkit-transition: top 0.3s ease-in-out;
  -moz-transition:    top 0.3s ease-in-out;
  -ms-transition:     top 0.3s ease-in-out;
  -o-transition:      top 0.3s ease-in-out;
  transition:         top 0.3s ease-in-out;
}

  .absolute {
  position: absolute;
  bottom: 3px;
  width: 1%;
  border: 3px solid #8AC007;
}

   
        #form{
  border-radius: 50px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin-top: 10%;
  
  position:absolute;
  top: 70%;
  left:50%;
  font-family: "Comic Sans MS", cursive, sans-serif;
  padding: 20px;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  display:block;
  width:600px;
  overflow-y: auto;
  height: 700px;
  }
  p.gfg{
      clear:both;
  }
  
  #floater {
    float: left;
    height: 80%;
    width: 100%;
    margin-bottom: -50px;
  }
    #child {
    clear: both;
    height: 100px;
}

    </style>
     <body>
    
<?php 


      $user=$_SESSION["username"];
      $query= "SELECT * FROM users WHERE username='$user'";
      $result=mysqli_query($conn,$query);
      $row=mysqli_fetch_array($result);
       if($row['type']==='admin'){
        if(isset($_SESSION['username'])){
      ?>
			<center>
	
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but5()">Users Requests</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
 
    
    <div id="form">
              <?php
              if($_GET["id"]){
                  $check=mysqli_query($conn,"SELECT * FROM posts WHERE id='".$_GET['id']."'");
                  if(!$check || $result= mysqli_num_rows($check)){
                      while($row = mysqli_fetch_assoc($check)){
                          echo "<h1>".$row['title']."</h1>";
                          echo "<h5>User:".$row['name']."<br/>Date:".$row['date']."<br/>Likes:".$row['likes']."<h5/>";
                          echo "<br/>".$row['question'];
                          $id= $row['id'];
                          echo "<br><a href=modify.php?id=$id>".'Modify'."</a>";
                          
                          ?>
                          
                     <form action="" method="POST">
                    
                    <button type="submit"  name="like">Like</button>
              </form>
                          
                  <form action="" method="POST">
                    
                    <button type="submit"  name="dislike">Dislike</button>
              </form>         
                <?php 
                    $like=$row['likes'];
                    if (isset($_POST['like'])){
                            $like=$like+1;
                            $result=mysqli_query($conn,"UPDATE posts SET likes = '$like' WHERE id = $id");
                           
                    }elseif(isset($_POST['dislike'])) {
                           $like=$like-1;
                            $result=mysqli_query($conn,"UPDATE posts SET likes = '$like' WHERE id = $id");
                    }
                
                
                
                 ?>
                          
                          
                          
                         
                          
                          
                                   <form action="" method="POST">
              <h3>Comment</h3> </br><textarea  name="answers"  style=" width:400px; height:100px; " placeholder="Enter your text here..."></textarea><br>
                    <button type="submit"  name="submit1">Comment</button>
              </form>
              <?php
                  if (isset($_POST['submit1'])){
      
      $answers= $_POST['answers'];
      $id=$_GET['id'];
      if($answers){
      $query="insert into answers values('$id',DEFAULT, '$user' , '$answers', DEFAULT ,DEFAULT,DEFAULT)";
      $result=mysqli_query($conn,$query); 
      if($result===false){
					echo "Error is ". mysqli_error($conn);
					die();
				}else{
				    echo "Your comment has been submitted!!!<br>";
        echo '<meta http-equiv="refresh" content="3; url=questions.php?id='.$row['id'].'">';
        die();
      }
      }
                  }
                        }
                  }
              }else{
                  echo "Topic not found";
              }
              if($_GET["id"]){
                  $check=mysqli_query($conn,"SELECT * FROM answers WHERE id='".$_GET['id']."'");
                  if(!$check || $result= mysqli_num_rows($check)){
                      while($row = mysqli_fetch_assoc($check)){
                          echo "<h5>User:".$row['user'].     " Date:".$row['date']."</h5>";
                          echo "<br/>".$row['answers'];
              
                      }
                  }
              }
              
              ?>
              
              

          
    </div>
	</center>
	<?php
        
}
}
		
		else if($row['type']==='user'){
		    if(isset($_SESSION['username'])){
			echo "Hello ".$_SESSION['username']."<br>";
			?>
			<center>
	
	<div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but4()">Home Page</button></li>
        <li><button class="bt1" onclick="but6()">Submit a Post</button></li>
        <li><button class="bt1" onclick="but8()">Log Out</button></li>
    </ul>
    </div>
    <div id="form">
              <?php
              if($_GET["id"]){
                  $check=mysqli_query($conn,"SELECT * FROM posts WHERE id='".$_GET['id']."'");
                  if(!$check || $result=mysqli_num_rows($check)){
                      while($row = mysqli_fetch_assoc($check)){
                          echo "<h1>".$row['title']."</h1>";
                          echo "<h5>User:".$row['name']."<br/>Date:".$row['date']."<br/>Likes:".$row['likes']."<h5/>";
                          echo "<br/>".$row['question'];
                          ?>
                          <form action="" method="POST">
                    
                    <button type="submit"  name="like">Like</button>
              </form>
                          
                  <form action="" method="POST">
                    
                    <button type="submit"  name="dislike">Dislike</button>
              </form>         
                <?php 
                    $like=$row['likes'];
                    if (isset($_POST['like'])){
                            $like=$like+1;
                            $result=mysqli_query($conn,"UPDATE posts SET likes = '$like' WHERE id = $id");
                           
                    }elseif(isset($_POST['dislike'])) {
                           $like=$like-1;
                            $result=mysqli_query($conn,"UPDATE posts SET likes = '$like' WHERE id = $id");
                    }
                
                
                
                 ?>
                                   <form action="" method="POST">
              <h3>Comment</h3> </br><textarea  name="answers"  style=" width:400px; height:100px; " placeholder="Enter your text here..."></textarea><br>
                    <button type="submit"  name="submit1">Comment</button>
              </form>
              <?php
                  if (isset($_POST['submit1'])){
      
      $answers= $_POST['answers'];
      $id=$_GET['id'];
      if($answers){
      $query="insert into answers values('$id',DEFAULT, '$user' , '$answers', DEFAULT ,DEFAULT,DEFAULT)";
      $result=mysqli_query($conn,$query); 
      if($result===false){
					echo "Error is ". mysqli_error($conn);
					die();
				}else{
				    echo "Your comment has been submitted!!!<br>";
        echo '<meta http-equiv="refresh" content="3; url=questions.php?id='.$row['id'].'">';
        die();
				}
				}    
                        }
                  }
              }
                      
              else{
                  echo "Topic not found";
              }
              if($_GET["id"]){
                  $check=mysqli_query($conn,"SELECT * FROM answers WHERE id='".$_GET['id']."'");
                  if(!$check || $result= mysqli_num_rows($check)){
                      while($row = mysqli_fetch_assoc($check)){
                          echo "<h3>User:".$row['user'].     " Date:".$row['date']."<h3/>";
                          echo "<br/>".$row['answers'];
              
                      }
                  }
              }
              
              
              
              ?>
	</center>
	<?php
	 	  }  } }
		else {
		    echo "<script>alert('Log in first!!!');</script>";
		    echo '<meta http-equiv="refresh" content="0; url=sindesi.php">';
		}
      ?>
        
          
          </div>
          
      
      </body>

</html>