function but0(){
window.location.assign("index.php");
 }
function but1(){
window.location.assign("sindesi.php");
 }
 function but2(){
 window.location.assign("eggrafh.php");
}
function but3(){
window.location.assign("info.php");
}

