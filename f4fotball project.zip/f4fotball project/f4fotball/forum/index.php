<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title> Forum </title>
  <link rel="stylesheet" type="text/css" href="startcss.css">
  <style>img[alt="www.000webhost.com"]{display:none;}</style>
</head>
<style>
 #form{
  border-radius: 50px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin-top: 30%;
  width: 300px;
  position:absolute;
  left:50%;
  font-family: "Comic Sans MS", cursive, sans-serif;
  padding: 20px;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  display:block;
  overflow-y: auto;
  
  }

</style>
<body>


  <div id="div1">
  <ul id="list">
      <li><button class="bt1" onclick="but0()">Home Page</button></li>
      <li><button class="bt1" onclick="but1()">Log in</button></li>
      <li><button class="bt1" onclick="but2()">Sign in</button></li>
      <li><button class="bt1" onclick="but3()">Info</button></li>
  </ul>
</div>
<script src="assign.js">
</script>
<div id="form">
    <h3>Welcome to  F4football. F4football is a univercity project forum where you can talk about football with other fans of the sport. You can post your own unique question as well as answer in other people's questions. We hope you enjoy your stay!</h3>
    </div>
</body>
</html>