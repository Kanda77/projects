<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
  </head>
<body>

<form action="" method="POST">
<input type="text" name="username" value="<?php if (isset($_POST['username'])) {echo $_POST['username'];} ?>"  placeholder="Enter your name.." required><br>
<input type="password"  name="password" value="<?php if (isset($_POST['password'])){echo $_POST['password'];} ?>"  placeholder="Enter your password.." required><br>
<input type="email" name="email" value="<?php if (isset($_POST['email'])){echo $_POST['email'];} ?>" placeholder="Enter your email.." required><br>
<input type="checkbox" name="checkbox" required><br>
<input type="submit" name="submit" id="bn2"  value="Sign in"><br>
</form>
</body>
</html>