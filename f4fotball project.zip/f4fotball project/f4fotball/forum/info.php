<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Info</title>
    <link rel="stylesheet" type="text/css" href="startcss.css">
    <style>img[alt="www.000webhost.com"]{display:none;}</style>
  </head>
  <style>
  .form{
  border-radius: 50px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin: 0;
  margin-top: 50px;
  position: absolute;
  top: 50%;
  left: 50%;
  font-family: "Comic Sans MS", cursive, sans-serif;
  padding: 20px;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  }

    #myDIV{
       width: 85%;

    }
    #myDIV2{
       width: 85%;

    }
    #myDIV3{
       width: 85%;

    }
    button { cursor:pointer; }
    </style>
  <body>
    <div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but0()">Home Page</button></li>
        <li><button class="bt1" onclick="but1()">Log in</button></li>
        <li><button class="bt1" onclick="but2()">Sign in</button></li>
        <li><button class="bt1" onclick="but3()">Info</button></li>
    </ul>
    </div>
<div class="form">
<h3>Some info about the admins..</h3>
<button onclick="Zoulas()">GiZou</button><br>
<div id="myDIV" hidden>
Name: Giwrgos<br>
Surname: Zoulas<br>
Email: zoulasgiwrgos@gmail.com<br>
Age: 21<br>
</div>
<button onClick="Rapanakis()">PiouComing</button><br>
<div id="myDIV2" hidden>
Name: Giannhs<br>
Surname: Rapanakhs<br>
Email: ggiannis405@gmail.com<br>
Age: 21<br>
</div>
<button onClick="Emilio()">Kanda</button><br>
<div id="myDIV3" hidden>
Name: Emilio<br>
Surname: Capoku<br>
Email: capoku17@gmail.com<br>
Age: 21<br>
</div>
</div>
  </body>
  <script src="assign.js"></script>
  <script src="aboutus.js"></script>
</html>
