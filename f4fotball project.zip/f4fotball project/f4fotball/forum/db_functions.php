<?php
	function db_connect(){
		static $connection;
		if(!isset($connection)){// an den exei ginei syndesh pio prin
			$config=parse_ini_file('../config.ini');
			$connection=mysqli_connect($config['server'],$config['username'],$config['password'],$config['dbname']);
		}
		if($connection===false){
			echo mysqli_connect_error();
			die();
		}
		return $connection;		
		
	}



?>