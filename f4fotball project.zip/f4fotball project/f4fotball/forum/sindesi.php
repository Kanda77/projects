<?php

session_start();
?>
<!DOCTYPE html>
<html>
<head>
    
    
<meta charset="utf-8">
<title>Log in</title>
<link rel="stylesheet" type="text/css" href="startcss.css">
<style>img[alt="www.000webhost.com"]{display:none;}</style>




</head>
<style>
h2{
font-family: "Comic Sans MS", cursive, sans-serif;
}
.form{
border-radius: 110px;
border: 5px solid black;
background-image: url(2277.jpg);
margin: 0;
position: absolute;
top: 60%;
left: 50%;
padding: 50px;
font-family: "Comic Sans MS", cursive, sans-serif;
-ms-transform: translate(-50%, -50%);
transform: translate(-50%, -50%);
cursor: :pointer;
}
input[type="submit"] {
cursor: pointer;
color: black;
-webkit-text-stroke-width: 1px;
font-family: "Comic Sans MS", cursive, sans-serif;
-webkit-text-stroke-color: black;
border-radius: 35px;
background-color: white ;
border: 2px solid black;
font-size: 18px;
padding: 10px 10px;
margin-left: 50px;
margin-top: 17px;
}
</style>
<body>

      
     
    <div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but0()">Home Page</button></li>
        <li><button class="bt1" onclick="but1()">Log in</button></li>
        <li><button class="bt1" onclick="but2()">Sign in</button></li>
        <li><button class="bt1" onclick="but3()">Info</button></li>
    </ul>
  </div>

    <div class="form">
    <h2> Σύνδεση.. </h2>
<?php
    require_once('db_functions.php');
	$conn=db_connect();
	if(isset($_POST['submit'])){
			$u=$_POST['username'];
			$p=$_POST['password'];
			$p=md5($p);
			$query="select * from users where username='$u' and password='$p'";
			//echo $query."<br>";
			$result=mysqli_query($conn,$query);
			if($result===false){
				echo "Error is ". mysqli_error($conn);
				die();
			}else{
				if(mysqli_num_rows($result)==1){
					echo "You have been logged in!!!<br> ";
					$_SESSION['username']=$u;
					echo '<meta http-equiv="refresh" content="2; url=anamonh.php">';
					die();
					
				}else{
					echo "Wrong username or password<br>";
				}
			}
		}
	
?>
    <form action="" method="POST">
      <input type="text" name="username" value="<?php if (isset($_POST['username'])) {echo $_POST['username'];} ?>" placeholder="Enter your username.." required><br>
      <input type="password"  name="password" value="<?php if (isset($_POST['password'])){echo $_POST['password'];} ?>" placeholder="Enter your password.." required><br>
      <input type="submit" name="submit" id="bn" value="Log in"  ><br>
    </form>
    </div>
    <script src="assign.js"></script>
  </body>
</html>
