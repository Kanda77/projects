<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sign in</title>
      <link rel="stylesheet" type="text/css" href="startcss.css">
      <style>img[alt="www.000webhost.com"]{display:none;}</style>
  </head>
  <style>
  h2{
    font-family: "Comic Sans MS", cursive, sans-serif;
  }
  .form{
  border-radius: 110px;
  border: 5px solid black;
  background-image: url(2277.jpg);
  margin: 0;
  position: absolute;
  top: 60%;
  left: 50%;
  padding: 50px;
  font-family: "Comic Sans MS", cursive, sans-serif;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  }
  input[type="submit"] {
               cursor: pointer;
               color: black;
               -webkit-text-stroke-width: 1px;
               font-family: "Comic Sans MS", cursive, sans-serif;
               -webkit-text-stroke-color:gray;
               border-radius: 35px;
               background-color: white;
               border: 2px solid black;
               font-size: 18px;
               padding: 10px 10px;
               margin-left: 50px;

             }


</style>
  <body>
    <div id="div1">
    <ul id="list">
        <li><button class="bt1" onclick="but0()">Home Page</button></li>
        <li><button class="bt1" onclick="but1()">Log in</button></li>
        <li><button class="bt1" onclick="but2()">Sign in</button></li>
        <li><button class="bt1" onclick="but3()">Info</button></li>
    </ul>
  </div>
   <div class="form">
    <h2> Sign In... </h2>
<?php
      require_once('db_functions.php');
      $conn=db_connect();
      if (!isset($_POST['submit'])){
        include "registerform.php";
      }else{
      $user = $_POST['username'];
      $pass = $_POST['password'];
      $email = $_POST['email'];
      $type="user";//user
      $conf=0;
      $errors = array();
      if (strlen($user)<5) {
        array_push($errors, "The username must be longer than 5 characters.");
      }
      if (strlen($pass)<7){
        array_push($errors, "Your password must be longer than 7 characters.");
      }
      if (!empty($errors)){
        echo "<h3>You got the following erroes:</h3>";
        foreach ($errors as $e) {
          echo $e."<br>";
        }
        include "registerform.php";
      }else{
        
        $query="select * from users where username='$user' or email='$email'";
			//echo $query."<br>";
			$result=mysqli_query($conn,$query);
			if($result===false){
				echo "Error is ". mysqli_error($conn);
				die();
			}
			if(mysqli_num_rows($result)>0){
				echo "Username or email already exists!!!<br>";
				
				include "registerform.php";
			}else{
				
				
				$pass=md5($pass);
				$query="insert into users values(DEFAULT,'$user','$pass','$email','$type','$conf')";
				//echo $query."<br>";
				$result=mysqli_query($conn,$query);
				if($result===false){
					echo "Error is ". mysqli_error($conn);
					die();
				}else{
				    echo "Congratulations!You are now a member of our forum!<br>";
        echo '<meta http-equiv="refresh" content="3; url=sindesi.php">';
        die();
      }
    }
    }
      }
?></div>
    <script src="assign.js"></script>
  </body>
</html>
