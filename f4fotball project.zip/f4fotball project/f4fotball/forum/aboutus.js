function Zoulas() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "block") {
      x.style.display = "none";
  } else {
      x.style.display = "block";
  }
}
function Rapanakis() {
var x = document.getElementById("myDIV2");
if (x.style.display === "block") {
    x.style.display = "none";
} else {
    x.style.display = "block";
}
}
function Emilio() {
var x = document.getElementById("myDIV3");
if (x.style.display === "block") {
  x.style.display = "none";
} else {
  x.style.display = "block";
}
}
